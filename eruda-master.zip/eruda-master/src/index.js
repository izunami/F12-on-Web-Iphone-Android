const eruda = require('./eruda').default
module.exports = eruda
module.exports.default = eruda

//# sourceMappingURL=index.js.map
