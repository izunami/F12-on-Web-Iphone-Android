eruda.init({
  useShadowDom: false,
})
